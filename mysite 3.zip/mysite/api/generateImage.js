// Vercel Serverless Function — توليد الصور (Imagen عبر Gemini API).
// هذا الملف خاصو يكون فـ:  api/generateImage.js  (فجذر المشروع)
// نفس مفتاح GEMINI_API_KEY يتحط فـ Environment Variables على Vercel.

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: { message: 'Method not allowed' } });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: { message: 'GEMINI_API_KEY غير مضبوط فـ Environment Variables على Vercel' } });
  }

  try {
    const payload = req.body || {};
    const modelId = payload.modelId || 'imagen-4.0-generate-001';

    const upstream = await fetch(
      GEMINI_BASE + encodeURIComponent(modelId) + ':predict?key=' + encodeURIComponent(apiKey),
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instances: payload.instances, parameters: payload.parameters }),
      }
    );
    const text = await upstream.text();
    res.status(upstream.status);
    res.setHeader('Content-Type', 'application/json');
    return res.send(text);
  } catch (e) {
    return res.status(500).json({ error: { message: 'خطأ فالخادم: ' + e.message } });
  }
};
