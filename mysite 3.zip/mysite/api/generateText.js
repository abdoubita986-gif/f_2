// Vercel Serverless Function — يخدم فنفس مشروع Vercel، بلا حاجة لـ Cloudflare
// ولا Netlify. المفتاح يتحط فـ Project Settings → Environment Variables
// باسم GEMINI_API_KEY (ماشي مكتوب هنا فالكود، ومحفوظ عند Vercel فقط).
//
// هذا الملف خاصو يكون فـ:  api/generateText.js  (فجذر المشروع)

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models/';

module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: { message: 'Method not allowed' } });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: { message: 'GEMINI_API_KEY غير مضبوط فـ Environment Variables على Vercel' } });
  }

  try {
    const payload = req.body || {};
    const modelId = payload.modelId || 'gemini-3.5-flash';
    const body = {
      contents: payload.contents,
      systemInstruction: payload.systemInstruction,
      generationConfig: payload.generationConfig,
    };
    if (payload.tools) body.tools = payload.tools;

    const upstream = await fetch(
      GEMINI_BASE + encodeURIComponent(modelId) + ':generateContent?key=' + encodeURIComponent(apiKey),
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    );
    const text = await upstream.text();
    res.status(upstream.status);
    res.setHeader('Content-Type', 'application/json');
    return res.send(text);
  } catch (e) {
    return res.status(500).json({ error: { message: 'خطأ فالخادم: ' + e.message } });
  }
};
