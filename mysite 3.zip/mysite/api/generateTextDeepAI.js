// api/generateTextDeepAI.js
// ---------------------------------------------------------------------------
// Third-tier text provider for the abdelrezakbezzag AI Workspace.
//
// Chain: Gemini (api/generateText.js) -> DeepSeek (api/generateTextFallback.js)
//        -> DeepAI (this file), each tried only after the previous one fails
//        with a retryable error (quota / rate limit / 5xx).
//
// SECURITY: the DeepAI key lives ONLY in this server-side function, read from
// the DEEPAI_API_KEY environment variable in Vercel's Project Settings ->
// Environment Variables. It is never sent to, or embedded in, the browser.
// If you ever see a DeepAI key typed directly into client-side JavaScript,
// that key is exposed to anyone who opens dev tools — rotate it immediately
// and move the call server-side, as this file does.
//
// Setup:
//   1. Create/get a key at https://deepai.org (Settings -> API Keys).
//   2. In Vercel: Project Settings -> Environment Variables -> add
//      DEEPAI_API_KEY = <your key> -> redeploy.
//   3. That's it — the client already calls /api/generateTextDeepAI
//      automatically as the last resort in the fallback chain.
//
// Contract (kept identical to generateText.js / generateTextFallback.js so
// the client's response parsing works unchanged):
//   Request body:  { contents, systemInstruction, generationConfig }
//                  (Gemini's chat-history shape — see ChatManager._buildTextContents)
//   Success (200): { candidates: [ { content: { parts: [ { text } ] } } ] }
//   Failure:       { error: { message, code } } with a matching HTTP status.
//                  429/5xx are treated as "retryable" by the client, but since
//                  DeepAI is the last tier here, any failure simply surfaces
//                  to the user as an error.
// ---------------------------------------------------------------------------

module.exports = async function handler(req, res) {
    if (req.method !== 'POST') {
        res.status(405).json({ error: { message: 'الطريقة غير مسموحة، استخدم POST فقط.' } });
        return;
    }

    const apiKey = process.env.DEEPAI_API_KEY;
    if (!apiKey) {
        res.status(500).json({
            error: { message: 'DEEPAI_API_KEY غير مهيأ في متغيرات البيئة على Vercel. أضِفه في Project Settings ثم أعد النشر.' }
        });
        return;
    }

    try {
        const { contents, systemInstruction } = req.body || {};
        const prompt = buildPrompt(contents, systemInstruction);
        if (!prompt) {
            res.status(400).json({ error: { message: 'لا توجد رسالة صالحة لإرسالها.' } });
            return;
        }

        // DeepAI's text-generator endpoint expects multipart form data, not
        // JSON. Node 18+'s global FormData/fetch (available in Vercel's
        // Node.js runtime) handle this the same way the browser would.
        const body = new FormData();
        body.append('text', prompt);

        const upstream = await fetch('https://api.deepai.org/api/text-generator', {
            method: 'POST',
            headers: { 'api-key': apiKey },
            body
        });

        if (!upstream.ok) {
            const status = upstream.status;
            let message = 'تعذّر الاتصال بـ DeepAI (رمز ' + status + ')';
            try {
                const errJson = await upstream.json();
                if (errJson && (errJson.status || errJson.error)) {
                    message = String(errJson.status || errJson.error);
                }
            } catch (e) { /* body wasn't JSON */ }
            res.status(status >= 400 ? status : 502).json({ error: { message, code: status } });
            return;
        }

        const data = await upstream.json();
        const output = data && data.output;
        if (!output) {
            res.status(502).json({ error: { message: 'لم يُرجع DeepAI أي نص صالح.' } });
            return;
        }

        // Re-shape into the same Gemini-like envelope the client already parses.
        res.status(200).json({
            candidates: [{ content: { parts: [{ text: output }] } }]
        });
    } catch (error) {
        console.error('[api/generateTextDeepAI] unexpected error:', error);
        res.status(500).json({ error: { message: 'خطأ غير متوقع في خادم DeepAI: ' + error.message } });
    }
};

// DeepAI's text-generator is a plain single-string completion API, not a
// chat/multi-turn API like Gemini. So we flatten the Gemini-shaped
// `contents` history (and optional system instruction) into one prompt
// string, labeling turns so the model still has conversational context.
function buildPrompt(contents, systemInstruction) {
    const lines = [];
    const sys = systemInstruction && systemInstruction.parts
        ? systemInstruction.parts.map((p) => p.text || '').join(' ').trim()
        : '';
    if (sys) lines.push('[تعليمات النظام]: ' + sys);

    if (Array.isArray(contents)) {
        contents.forEach((turn) => {
            const text = (turn.parts || [])
                .map((p) => (typeof p.text === 'string' ? p.text : ''))
                .filter(Boolean)
                .join(' ')
                .trim();
            if (!text) return; // images/files aren't supported by this text-only fallback
            lines.push((turn.role === 'user' ? 'المستخدم' : 'المساعد') + ': ' + text);
        });
    }
    lines.push('المساعد:');
    // DeepAI has no hard documented prompt cap, but keep this bounded so a
    // very long chat history doesn't produce an oversized request.
    return lines.join('\n').slice(-12000);
}
