// api/generateTextFallback.js
// ============================================================================
// Secondary text-generation endpoint for abdelrezakbezzag.
//
// The client (index.html) calls this automatically — and only — when the
// primary provider (/api/generateText → Gemini) fails with a quota /
// rate-limit / server error. It is not used otherwise, so it costs nothing
// extra on a normal day.
//
// SECURITY — read this before deploying:
//   Put your DeepSeek key in Vercel's Environment Variables as
//   DEEPSEEK_API_KEY (Project → Settings → Environment Variables), then
//   redeploy. Never paste the raw key into this file or into index.html:
//   index.html ships to every visitor's browser, so any key written there
//   is trivially readable via "View Source" or the Network tab, and can be
//   copied and run up on your bill within minutes. This file runs only on
//   Vercel's server, which is the one place a key is actually hidden from
//   visitors.
// ============================================================================

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: { message: 'Method not allowed.' } });
  }

  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: { message: 'DEEPSEEK_API_KEY غير مضبوط في متغيرات البيئة على Vercel.' }
    });
  }

  try {
    const { contents = [], systemInstruction, generationConfig = {} } = req.body || {};

    // Convert the Gemini-shaped request the client already builds into the
    // OpenAI-compatible `messages` array DeepSeek's chat endpoint expects.
    const messages = [];

    const sysText = systemInstruction && Array.isArray(systemInstruction.parts)
      ? systemInstruction.parts.map((p) => p.text || '').join('\n').trim()
      : '';
    if (sysText) messages.push({ role: 'system', content: sysText });

    contents.forEach((c) => {
      const text = Array.isArray(c.parts)
        ? c.parts.map((p) => p.text || '').filter(Boolean).join('\n')
        : '';
      // DeepSeek's chat endpoint is text-only: inline images/PDFs that the
      // primary provider can read are silently dropped here rather than
      // sent as broken payload. This only affects the rare case where the
      // quota trip happens on a message that also had an attachment.
      if (!text) return;
      messages.push({ role: c.role === 'model' ? 'assistant' : 'user', content: text });
    });

    if (messages.length === 0) {
      return res.status(400).json({ error: { message: 'لا توجد رسالة نصية لإرسالها.' } });
    }

    const upstream = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + apiKey
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages,
        temperature: typeof generationConfig.temperature === 'number' ? generationConfig.temperature : 0.8,
        max_tokens: typeof generationConfig.maxOutputTokens === 'number' ? generationConfig.maxOutputTokens : 4096
      })
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      const message = (data && data.error && data.error.message) || 'تعذّر الاتصال بالمزوّد الاحتياطي (DeepSeek).';
      return res.status(upstream.status).json({ error: { message } });
    }

    const replyText = (data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content) || '';

    // Normalized to the same { candidates: [{ content: { parts } }] } shape
    // /api/generateText already returns, so the front-end's response
    // parsing needs no per-provider branching.
    return res.status(200).json({
      candidates: [{ content: { parts: [{ text: replyText }] } }]
    });
  } catch (err) {
    console.error('[generateTextFallback]', err);
    return res.status(500).json({ error: { message: 'خطأ داخلي في خادم المزوّد الاحتياطي.' } });
  }
}
