// api/generateTextStream.js
// ============================================================================
// Streaming twin of api/generateText.js for abdelrezakbezzag.
//
// Same request body as /api/generateText (modelId, contents, systemInstruction,
// generationConfig, optional tools), but proxies Gemini's streamGenerateContent
// endpoint (Server-Sent Events) straight through to the browser, so replies
// appear progressively instead of all at once. If this endpoint is
// unreachable or errors for any reason, the client already knows to fall
// back to the plain /api/generateText → /api/generateTextFallback chain, so
// nothing in the app breaks if streaming isn't available in some environment.
//
// Runs on Vercel's Edge Runtime, which is built for exactly this: piping a
// remote stream straight through without buffering the whole response in
// memory first.
//
// SECURITY: uses the same GEMINI_API_KEY as api/generateText.js, read from
// Vercel's Environment Variables. Never move this key into index.html or any
// other file that ships to the browser.
// ============================================================================

export const config = { runtime: 'edge' };

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: { message: 'Method not allowed.' } }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: { message: 'GEMINI_API_KEY غير مضبوط في متغيرات البيئة على Vercel.' } }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  let payload;
  try {
    payload = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: { message: 'طلب غير صالح (JSON).' } }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const { modelId, contents, systemInstruction, generationConfig, tools } = payload || {};
  if (!modelId || !Array.isArray(contents)) {
    return new Response(JSON.stringify({ error: { message: 'الطلب ناقص: modelId أو contents مفقود.' } }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  const url = 'https://generativelanguage.googleapis.com/v1beta/models/'
    + encodeURIComponent(modelId) + ':streamGenerateContent?alt=sse&key=' + apiKey;

  let upstream;
  try {
    upstream = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents, systemInstruction, generationConfig, ...(tools ? { tools } : {}) })
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: { message: 'تعذّر الوصول إلى Gemini.' } }), {
      status: 502,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  if (!upstream.ok || !upstream.body) {
    let message = 'تعذّر بدء البث من Gemini (رمز ' + upstream.status + ')';
    try {
      const errBody = await upstream.json();
      if (errBody && errBody.error && errBody.error.message) message = errBody.error.message;
    } catch (e) { /* not JSON */ }
    return new Response(JSON.stringify({ error: { message } }), {
      status: upstream.status || 502,
      headers: { 'Content-Type': 'application/json' }
    });
  }

  // Pipe Gemini's SSE stream straight through — the client parses the same
  // `data: {...}` lines it would get directly from Gemini.
  return new Response(upstream.body, {
    status: 200,
    headers: {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive'
    }
  });
}
